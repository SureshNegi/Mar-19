import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TopHeaderComponent } from './top-header/top-header.component';
import { SubHeaderComponent } from './sub-header/sub-header.component';
import { HeaderComponent } from './header.component';
import { FormsModule } from '@angular/forms';
import {AngularMaterialModule} from '../shared-module/angular.material.module';
@NgModule({
  declarations: [TopHeaderComponent, SubHeaderComponent, HeaderComponent],
  imports: [
    FormsModule,
    CommonModule,
    AngularMaterialModule
  ],
  exports: [HeaderComponent]
})
export class HeaderModule { }
