import { Component, OnInit } from '@angular/core';
import { MessageService } from '../../global/message.service';

@Component({
  selector: 'app-sub-header',
  templateUrl: './sub-header.component.html',
  styleUrls: ['./sub-header.component.css']
})
export class SubHeaderComponent implements OnInit {
  designateConfig: DesignateConfig = new DesignateConfig();
  constructor(private messageService: MessageService) { }
  ngOnInit() {
    this.designateConfig.placeHolderVal = 'Become a designate of...';
  }
  logout(sessKey: string, userAgent: string) {
    this.messageService.logOut('Message from Home Component to App Component!');
  }
}

class DesignateConfig {
  public displayName: string;
  public placeHolderVal: string;
}
