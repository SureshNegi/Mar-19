export enum APIStatusType {
    sucess = '0',
    fail = '2'
}

export class APIResponse {
    public RETCD: string;
    public ERRMSG: string;

}
