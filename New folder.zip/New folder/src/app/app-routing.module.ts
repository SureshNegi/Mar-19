// https://stackblitz.com/angular/yogmnknoxmv?file=src%2Fapp%2Fapp-routing.module.ts
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageNotFoundComponent } from './error-handling/404-page-not-found/page-not-found.component';
import { SelectivePreloadingStrategyService } from './selective-preloading-strategy.service';
import { AuthGuard } from './auth/auth.guard';
const appRoutes: Routes = [
  {
    path: 'dash',
    loadChildren: './employee-dashboard/employee-dashboard.module#EmployeeDashboardModule',
    canLoad: [AuthGuard]
  },
  // {
  //   path: 'crisis-center',
  //   loadChildren: './crisis-center/crisis-center.module#CrisisCenterModule',
  //   data: { preload: true }
  // },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  // { path: '**', component: PageNotFoundComponent }
];
@NgModule({
  imports: [RouterModule.forRoot(appRoutes, {
    enableTracing: true,
    preloadingStrategy: SelectivePreloadingStrategyService,
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
