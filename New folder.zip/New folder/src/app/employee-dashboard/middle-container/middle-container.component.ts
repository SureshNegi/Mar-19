import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-middle-container',
  templateUrl: './middle-container.component.html',
  styleUrls: ['./middle-container.component.css']
})
export class MiddleContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
