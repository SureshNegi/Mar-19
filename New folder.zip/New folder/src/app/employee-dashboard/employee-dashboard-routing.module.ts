import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeDeshboardComponent } from './employee-dashboard/employee-dashboard.component';
import { AuthGuard } from '../auth/auth.guard';
const appRoutes: Routes = [
    {
        path: 'home',
        component: EmployeeDeshboardComponent,
        canActivate: [AuthGuard],
        // children: [
        //     {
        //         path: '',
        //         canActivateChild: [AuthGuard],
        //         children: [
        //             { path: 'crises', component: ManageCrisesComponent },
        //             { path: 'heroes', component: ManageHeroesComponent },
        //             { path: '', component: AdminDashboardComponent }
        //         ]
        //     }
        // ]
    }
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)],
    exports: [RouterModule]
})
export class EmpDashboardRoutingModule { }
