// ng generate module EmployeeDashboard
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeDeshboardComponent } from './employee-dashboard/employee-dashboard.component';
import { EmpDashboardRoutingModule } from '../employee-dashboard/employee-dashboard-routing.module';
import {HeaderModule} from '../header/header.module';
import { LeftSlideBarComponent } from './left-slide-bar/left-slide-bar.component';
import { RightSlideBarComponent } from './right-slide-bar/right-slide-bar.component';
import { MiddleContainerComponent } from './middle-container/middle-container.component';
import {AngularMaterialModule} from '../shared-module/angular.material.module';

@NgModule({
  declarations: [EmployeeDeshboardComponent, LeftSlideBarComponent, RightSlideBarComponent, MiddleContainerComponent],
  imports: [
    HeaderModule,
    CommonModule,
    EmpDashboardRoutingModule,
    AngularMaterialModule
  ]
})
export class EmployeeDashboardModule { }
