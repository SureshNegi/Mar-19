import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-slide-bar',
  templateUrl: './right-slide-bar.component.html',
  styleUrls: ['./right-slide-bar.component.css']
})
export class RightSlideBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
