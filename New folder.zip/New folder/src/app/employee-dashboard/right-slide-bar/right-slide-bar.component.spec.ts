import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RightSlideBarComponent } from './right-slide-bar.component';

describe('RightSlideBarComponent', () => {
  let component: RightSlideBarComponent;
  let fixture: ComponentFixture<RightSlideBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RightSlideBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RightSlideBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
