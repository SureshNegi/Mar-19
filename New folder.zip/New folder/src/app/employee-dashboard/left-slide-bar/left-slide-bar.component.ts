import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-left-slide-bar',
  templateUrl: './left-slide-bar.component.html',
  styleUrls: ['./left-slide-bar.component.css']
})
export class LeftSlideBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
