//  https://stackblitz.com/edit/angular-material-login-form?file=src%2Fapp%2Flogin-form.component.ts
import { Component, OnInit } from '@angular/core';
import { Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
// import { UserLoginService } from '../service/user-login.service';
import { Router } from '@angular/router';
import { AuthService } from '../../auth/auth.service';
import { APILoginResponse } from '../models/api.login.response.model';
import { APIStatusType } from '../../global/api.status.flag';
import { MessageService } from '../../global/message.service';
import { Subscription } from 'rxjs';
import { APIResponse } from '../../global/api.status.flag';

@Component({
  selector: 'app-user-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  subscription: Subscription;
  browserAgent: string;
  constructor(public messageService: MessageService, public authService: AuthService, private router: Router) {
    this.browserAgent = escape(navigator.userAgent).substring(0, 100);
    this.subscription = this.messageService.getMessage().subscribe(message => {
      this.logOutEmployee();
    });
  }
  @Input() error: string | null;
  @Output() submitEM = new EventEmitter();
  apiResponse: APILoginResponse = new APILoginResponse();
  form: FormGroup = new FormGroup({
    username: new FormControl(''),
    password: new FormControl(''),
    saveUName: new FormControl('')
  });
  applicationVersion = '1.76';

  ngOnInit() {
  }

  logOutEmployee() {
    this.authService.logout(this.apiResponse.SESKEY, this.browserAgent).subscribe((data: APIResponse) => {
      if (data.RETCD === APIStatusType.sucess) {
        this.authService.isLoggedIn = false;
        this.router.navigate(['/login']);
      } else {
        alert(data.ERRMSG);
      }
    });
  }
  employeeLogin() {
    const loginInfo = this.validateLoginForm();
    if (loginInfo) {
      this.authService.login(loginInfo).subscribe((data: APILoginResponse) => {
        this.apiResponse = data;
        if (this.apiResponse.RETCD === APIStatusType.sucess) {
          this.router.navigate(['/home']);
          this.authService.isLoggedIn = true;
        }
      });
    }
  }
  validateLoginForm(): UserLoginInfo {
    const loginInfo: UserLoginInfo = new UserLoginInfo();
    loginInfo.name = this.form.controls['username'].value;
    loginInfo.password = this.form.controls['password'].value;
    loginInfo.agent = this.browserAgent;
    loginInfo.appVersion = this.applicationVersion;
    this.form.get('username');
    return loginInfo;
  }


}
class UserLoginInfo {
  name: string;
  password: string;
  agent: string;
  appVersion: string;
}
