import { Injectable } from '@angular/core';
import { APILoginResponse } from './models/api.login.response.model';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { APIResponse } from '../global/api.status.flag';

import { map, catchError, tap } from 'rxjs/operators';
const baseAPIURL = 'http://dev.api.mytime.mercer.com:8000/te_html5_htp_pkg';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
};

@Injectable({
    providedIn: 'root',
})
export class AuthService {
    isLoggedIn = false;

    // store the URL so we can redirect after logging in
    redirectUrl: string;
    constructor(private http: HttpClient) { }
    // login(): Observable<boolean> {
    //     return of(true).pipe(
    //         delay(1000),
    //         tap(val => this.isLoggedIn = true)
    //     );
    // }
    login(loginInfo: any): Observable<APILoginResponse> {
        let paramTemplate = 'I_JSON={"LOGIN_IN_OBJ" : {"USRNAME":"$1","PW":"$2","CLITYP":"$3","APPVER":"$4","UAGENT":"$5"}}';
        paramTemplate = paramTemplate.replace('$1', loginInfo.name);
        paramTemplate = paramTemplate.replace('$2', loginInfo.password);
        paramTemplate = paramTemplate.replace('$4', loginInfo.appVersion);
        paramTemplate = paramTemplate.replace('$5', loginInfo.agent);
        const apiURL = baseAPIURL + '.Login';
        return this.http.post<APILoginResponse>(apiURL, paramTemplate, httpOptions).pipe(
            // tap((response['LOGIN_OUT_OBJ']) =>
            //     response = response['LOGIN_OUT_OBJ']
            //    // return new APILoginResponse()
            //    // return response.LOGIN_OUT_OBJ
            // )// ,
            // // catchError(this.handleError<any>('addProduct'))
            map(response => {  // NOTE: response is of type SomeType
                // Does something on response.data
                // modify the response.data as you see fit.
                // return the modified data:
                response = response['LOGIN_OUT_OBJ'];
                return response; // kind of useless
            }),
            catchError(error => {
                return Observable.throw(error);
            })
        );
    }

    logout(sessKey: string, userAgent: string): Observable<APIResponse> {

        sessKey = encodeURIComponent(sessKey);
        userAgent = encodeURIComponent(userAgent);
        const paramTemplate = `?I_JSON={%22LOGOUT_IN_OBJ%22%20:%20{%22SESKEY%22:%22${sessKey}%22,%22UAGENT%22:%22${userAgent}%22}}`;
        const apiURL = baseAPIURL + '.Logout' + paramTemplate;
        return this.http.get<APIResponse>(apiURL).pipe(
            map(response => {  // NOTE: response is of type SomeType
                // Does something on response.data
                // modify the response.data as you see fit.
                // return the modified data:
                response = response['LOGOUT_OUT_OBJ'];
                return response; // kind of useless
            }),
            catchError(error => {
                return Observable.throw(error);
            })
        );
    }
}
