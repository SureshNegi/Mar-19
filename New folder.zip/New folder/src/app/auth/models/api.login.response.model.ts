export class APILoginResponse {
    public EMPLID: number;
    public ENCKEY: string;
    public ERRMSG: string;
    public ISNONAD: string;
    public NONADDAYSTOEXPIRE: string;
    public NONADLANG: string;
    public NONADPASSSTATUS: string;
    public NONADUSERNAME: string;
    public RETCD: string;
    public SESKEY: string;
}
